(function(window) {
    'use strict';

    var $ = window.jQuery;
    var App = window.App || {};

    var DefaultEasingFunctions = {
        linear: function(t) {
            return t;
        },
        easeIn: function(t) {
            return 1 - Math.cos(t * Math.PI/2.0);
        },
        easeOut: function(t) {
            return 1 - Math.cos((t - 1) * Math.PI/2.0);
        },
        easeInOut: function(t) {
            return 0.5 - Math.cos(t * Math.PI)/2.0;
        }
    }

    function Rect(x, y, width, height) {
        this.origin = {x: x, y: y};
        this.size = {width: width, height: height};
    }

    Rect.prototype.inset = function(xInset, yInset) {
        return new Rect(this.origin.x + xInset, this.origin.y + yInset, this.size.width - xInset*2, this.size.height - yInset*2);
    }

    Rect.prototype.offset = function(xOffset, yOffset) {
        return new Rect(this.origin.x + xOffset, this.origin.y + yOffset, this.size.width, this.size.height);
    }

    function SelectionArrow(cfg) {
        this.canvas = cfg.canvas;
        this.fetchedCanvasHeight = this.canvas.height;
        this.fetchedCanvasWidth = this.canvas.width;

        if (cfg.timingFunction) {
            if (typeof cfg.timingFunction === 'string') {
                 switch (cfg.timingFunction) {
                     case 'linear': this.timingFunction = DefaultEasingFunctions.linear; break;
                     case 'easeIn': this.timingFunction = DefaultEasingFunctions.easeIn; break;
                     case 'easeeut': this.timingFunction = DefaultEasingFunctions.easeOut; break;
                     case 'easeInOut': this.timingFunction = DefaultEasingFunctions.easeInOut; break;
                 }
            } else {
                this.timingFunction = cfg.timingFunction;
            }
        } else {
            this.timingFunction = DefaultEasingFunctions.linear
        }

        this.canvas.style.width = this.fetchedCanvasWidth+'px';
        this.canvas.style.height = this.fetchedCanvasHeight+'px';

        this.point = {};
        this.fillColor = cfg.fillColor || 'white';
        this.strokeColor = cfg.strokeColor || 'red';
        this.lineWidth = cfg.lineWidth || 1;
        this._arrowDepth = cfg.arrowDepth || 20;
        this._arrowWidth = cfg.arrowWidth || 40;
        this.animationDuration = cfg.animationDuration || 750;
        this.startTime = undefined;

        if (cfg.point !== undefined) {
            this.setArrowPoint(cfg.point, false);
        }

        window.matchMedia('only screen and (-webkit-min-device-pixel-ratio: 2)').addListener(function(e) {
            this.draw();
        }.bind(this));
    }

    SelectionArrow.prototype.setArrowPoint = function(point, animated, pTimestamp, completionHandler) {
        var animated = animated || false;
        if (!animated || Object.keys(this.point).length === 0) {
            this.point = point;
            this.draw();
        } else {
            if (pTimestamp === undefined) {
                window.requestAnimationFrame(function(timestamp) {
                    this.setArrowPoint(point, true, timestamp, completionHandler);
                }.bind(this));
            } else {

                if (this.startTime === undefined) {
                    this.startTime = pTimestamp;
                }

                var xPointDelta = point.left - this.point.left;
                var t = Math.min((pTimestamp - this.startTime) / this.animationDuration, 1);
                var newPoint = {left: this.point.left + xPointDelta * this.timingFunction(t), top: this.point.top};

                this.draw(newPoint);

                if (t !== 1) {
                    window.requestAnimationFrame(function(timestamp) {
                        this.setArrowPoint(point, true, timestamp, completionHandler);
                    }.bind(this));
                } else {
                    this.point = point;
                    this.startTime = undefined;
                    if (completionHandler !== undefined) {
                        completionHandler();
                    }
                }
            }
        }
    }

    SelectionArrow.prototype.draw = function(point) {
        var scaleFactor = window.App.Helper.backingScale();

        var point = point || {left: this.point.left, top: this.point.top};
        point.left *= scaleFactor;
        point.top *= scaleFactor;

        var arrowWidth = this._arrowWidth * scaleFactor;
        var arrowDepth = this._arrowDepth * scaleFactor;
        var lineWidth = this.lineWidth * scaleFactor;

        this.canvas.width = this.fetchedCanvasWidth * scaleFactor;
        this.canvas.height = this.fetchedCanvasHeight * scaleFactor;

        var rect = new Rect(0, 0, this.canvas.width, this.canvas.height);

        var ctx = this.canvas.getContext('2d');
        ctx.clearRect(rect.origin.x, rect.origin.y, rect.size.width, rect.size.height);
        rect = rect.inset(-lineWidth, -lineWidth/2.0).offset(0, lineWidth);

        ctx.beginPath();
        ctx.moveTo(rect.origin.x, rect.origin.y);
        ctx.lineTo(point.left - arrowWidth / 2.0, rect.origin.y);
        ctx.lineTo(point.left, arrowDepth + rect.origin.y);
        ctx.lineTo(point.left + arrowWidth / 2.0, rect.origin.y);
        ctx.lineTo(rect.size.width, rect.origin.y);
        ctx.lineTo(rect.size.width, rect.size.height);
        ctx.lineTo(rect.origin.x, rect.size.height);
        ctx.closePath();

        ctx.fillStyle = this.fillColor;
        ctx.strokeStyle = this.strokeColor;
        ctx.fill();
        if (lineWidth > 0) {
            ctx.lineWidth = lineWidth;
            ctx.stroke();
        }
    }

    App.SelectionArrow = SelectionArrow;
    window.App = App;

})(window);
