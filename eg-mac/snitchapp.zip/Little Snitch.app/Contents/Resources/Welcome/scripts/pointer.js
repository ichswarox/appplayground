(function(window) {
    var App = window.App || {};
    var $ = window.jQuery;

    var clickDuration = 250;
    var doubleclickDuration = 500;

    const _mouseCursorSpeedMultipliers = {
        fast: 0.13,
        normal: 0.11,
        slow: 0.09
    };

    /*
      Create new instance of mouse pointer
      @param {Selector} selector - object identified via selector to which the mousepointer should be appended
      @param {Object} pConfiguration - Additional configuration
    */
    function Pointer(selector, pConfiguration) {
        // create pointer in selector
        this.configuration = {
            speed: (typeof pConfiguration === 'object') ? pConfiguration.speed || 'normal' : 'normal',
                // valid values: 'fast', 'normal', 'slow', default is 'normal'
            distance: (typeof pConfiguration === 'object') ? pConfiguration.distance || 25 : 25
                // default distance is 25 pixel
        };

        var $container = $(selector);
        if ($container.length === 0) {
            throw new Error('Container specified with selector(' + selector + ') not found');
        }

        this.$pointer = $('<div class="pointer-container"></div>');
        this.$pointer.append($('<div class="pointer"></div>'));
        this.$pointer.append($('<div class="pointer-pulse"></div>'));
        $container.append(this.$pointer);
    }

    Pointer.prototype.durationForDistance = function(distance) {
        var speed = (typeof this.configuration.speed === 'string') ? _mouseCursorSpeedMultipliers[this.configuration.speed] || 'normal' : 'normal';
        return distance / speed;
    }

    /*
        Show cursor, move to certain position, perform single click and
        fade out pointer if keepOnScreen !== undefined specified.
        @param {Object} position - Position to which mouse pointer should be moved {x: {Number, y: {Number}
        @param {Function} completionHandler - Function to call after click was performed
        @param {Number} keepOnScreenFor - Time in (ms) specifying how long the cursor should be kept on screen before fade out.
                                          If not specified, the cursor remains on screen.
    */
    Pointer.prototype.click = function(position, completionHandler, keepOnScreenFor) {
        var $pointer = this.$pointer;
        var _performClick = function() {
            setTimeout(function() {
                if (completionHandler !== undefined && typeof completionHandler == 'function') {
                    completionHandler(this);
                }

                $pointer.removeClass('click');

                setTimeout(function() {
                    if (keepOnScreenFor !== undefined) {
                        this.hide();
                    }
                }.bind(this), keepOnScreenFor);
            }.bind(this), clickDuration);
            $pointer.addClass('click');
        }.bind(this);

        if ($pointer.hasClass('show') === false) {
            this.move(position, function() {
                setTimeout(function() {
                    _performClick.bind(this)();
                }.bind(this), 25);
            }.bind(this));
        } else {
            _performClick.bind(this)();
        }
    }

    /*
        Show cursor, move to certain position, perform double click and
        fade out pointer if keepOnScreen !== undefined specified.
        @param {Object} position - Position to which mouse pointer should be moved {x: {Number, y: {Number}
        @param {Function} completionHandler - Function to call after click was performed
        @param {Number} keepOnScreenFor - Time in (ms) specifying how long the cursor should be kept on screen before fade out.
                                          If not specified, cursor remains on screen.
    */
    Pointer.prototype.doubleclick = function(position, completionHandler, keepOnScreenFor) {
        const $pointer = this.$pointer;
        var _performClick = function() {
            setTimeout(function() {
                if (completionHandler !== undefined && typeof completionHandler == 'function') {
                    completionHandler(this);
                }

                $pointer.removeClass('doubleclick');

                setTimeout(function() {
                    if (keepOnScreenFor !== undefined) {
                        this.hide();
                    }
                }.bind(this), keepOnScreenFor);
            }.bind(this), doubleclickDuration);

            $pointer.addClass('doubleclick');
        }.bind(this);

        if ($pointer.hasClass('show') === false) {
            this.move(position, function() {
                setTimeout(function() {
                    _performClick.bind(this)();
                }.bind(this), 25);
            });
        } else {
            _performClick.bind(this)();
        }
    }

    /*
        Show cursor, and move to certain position.
        @param {Object} position - Position to which mouse pointer should be moved {x: {Number, y: {Number}
        @param {Function} completionHandler - Function to call after click was performed
        @param {Number} keepOnScreenFor - Time in (ms) specifying how long the cursor should be kept on screen before fade out.
                                          If not specified, cursor remains on screen.
    */
    Pointer.prototype.move = function(position, completionHandler) {
        const $pointer = this.$pointer;

        if ($pointer.hasClass('show') === false) {
            var distance = this.configuration.distance;
            $pointer.css({
                left: Math.ceil(position.left + (-distance / 2.0 + Math.random() * distance)),
                top: Math.ceil(position.top + (distance + Math.random() * distance))
            });
            $pointer.addClass('show');
        }

        var currentPosition = $pointer.position();
        var distanceForMouseToMove = Math.sqrt(Math.pow(position.left - currentPosition.left, 2) + Math.pow(position.top - currentPosition.top, 2));
        var durationOfMouseMovement = this.durationForDistance(distanceForMouseToMove);

        setTimeout(function() {
            $pointer.addClass('translate');
            $pointer.css({
                'transition-duration': durationOfMouseMovement + 'ms'
            });
            $pointer.css({
                left: position.left,
                top: position.top
            });

            setTimeout(function() {
                if (completionHandler !== undefined && typeof completionHandler == 'function') {
                    completionHandler(this);
                }

                $pointer.removeClass('translate');
            }, durationOfMouseMovement);

        }.bind(this), 25);
    }

    /*
        Hide cursor again.
    */
    Pointer.prototype.hide = function() {
        this.$pointer.removeClass('show');
    }

    App.Pointer = Pointer;
    window.App = App;
})(window);
