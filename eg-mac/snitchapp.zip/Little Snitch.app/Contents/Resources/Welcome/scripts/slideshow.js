(function(window) {
    'use strict';

    var App = window.App || {};
    var $ = window.jQuery;

    /*
      @param {String} selctor - Selector refering to an div element to show slides
      @param {Object} slides - JSON {{src: string, srcSet: string}*}
      @param {Number} stepDuration - Time in ms specifying how long each slide should be on screen
      @param {Function} slideChangeHandler - Called on every slide change
      @param {Booelan} repeat - If set to true, after last slide has been shown, restarts with slide at index 0, otherwise stop animation and keep last slide shown
    */
    function Slideshow(selector, slides, timeOnScreenPerSlide, slideChangeHandler, repeat) {
        var $slideShowContainer = $(selector);
        if ($slideShowContainer.length === 0) {
            throw new Error('Slideshow: Element satisfying selector [' + selector + '] not found');
        }

        if ($slideShowContainer.children().length !== 0) {
          throw new Error('Slideshow: Supplied container must be an empty div');
        }

        slides.forEach(function(slide) {
          var $image = $('<img>');
          $image.attr('src', slide.src);
          $image.attr('srcset', slide.srcset);
          $image.css({display: 'none'});
          $slideShowContainer.append($image);
        });

        this.$slideShowContainer = $slideShowContainer;
        this.timeOnScreenPerSlide = timeOnScreenPerSlide || 500; // ms
        this.repeat = repeat || false;;
        this.numberOfSlides = slides.length;
        this.indexOfSlideCurrentlyShown = 0;
        this.slideChangeHandler = slideChangeHandler;
        this.animate = false;

        _showSlide(this, 0);
    }

    function _showSlide(slideShow, slideIndex) {
        var $children = slideShow.$slideShowContainer.children();
        $children.each(function() {
          $(this).css({display: 'none'});
        });

        if (slideIndex < 0 || slideShow > slideShow.numberOfSlides) {
            throw new Error('SlideShow: Request slide not withing range. '+slideIndex);
        }

        $($children[slideIndex]).css({display: 'inline'});
    }

    function _indexOfNextSlide(slideShow) {
      var indexOfNextSlide = slideShow.indexOfSlideCurrentlyShown + 1;
      if (indexOfNextSlide >= slideShow.numberOfSlides) {
          return slideShow.repeat ? 0 : slideShow.indexOfSlideCurrentlyShown;
      }
      return indexOfNextSlide;
    }

    function _showNextSlideRecursive(slideShow) {
        if (slideShow.animate == false) {
            return;
        }

        _showNextSlide(slideShow);

        setTimeout(function() {
          _showNextSlideRecursive(slideShow);
        }, slideShow.timeOnScreenPerSlide);
    }

    function _showNextSlide(slideShow) {
      var indexOfNextSlide = _indexOfNextSlide(slideShow);
      if (indexOfNextSlide == slideShow.indexOfSlideCurrentlyShown) {
        slideShow.animate = false;
        return;
      }

      _showSlide(slideShow, indexOfNextSlide);
      if (slideShow.slideChangeHandler !== undefined) {
          slideShow.slideChangeHandler(slideShow, indexOfNextSlide);
      }

      slideShow.indexOfSlideCurrentlyShown = indexOfNextSlide;
    }

    /*
      Begin SlideShow
    */
    Slideshow.prototype.start = function() {
        this.animate = true;
        this.indexOfSlideCurrentlyShown = -1;
        _showNextSlideRecursive(this);
    }

    /*
      Reset specified slideChangeHandler
      @param {Function} slideChangeHandler - SlideChangeHandler to set
    */
    Slideshow.prototype.setSliceChangeHandler = function(slideChangeHandler) {
        this.slideChangeHandler = slideChangeHandler;
    }

    /*
      Show next slide
    */
    Slideshow.prototype.next = function() {
        _showNextSlide(this);
    }

    /*
      Pause slide show
    */
    Slideshow.prototype.pause = function() {
        this.animate = false;
    }

    /*
      Resume paused slideshow
    */
    Slideshow.prototype.resume = function() {
        this.animate = true;
        _showNextSlideRecursive(this);
    }

    /*
      Same as pause
    */
    Slideshow.prototype.stop = function() {
        this.animate = false;
    }

    /*
        Compute estimated runtime for showing all sides. (Ignoes repeat flag)
        @return {Number}
    */
    Slideshow.prototype.estimatedRuntime = function() {
      var numberOfSlides = this.numberOfSlides || 0;
      var timeOnScreenPerSlide = this.timeOnScreenPerSlide || 0;

      return max(this.numberOfSlides - 1, 0) * timeOnScreenPerSlide;
    }

    App.Slideshow = Slideshow;
    window.App = App;

})(window);
