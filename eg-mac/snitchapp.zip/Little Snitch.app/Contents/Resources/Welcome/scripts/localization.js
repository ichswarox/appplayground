(function(window) {
    'use strict';

    var LOCALIZABLE_QUERY_STRING = '[data-localizable-string]';
    var $ = window.jQuery;

    /*
      Bridge Interface:
      Bridge.prototype.currentLocale: String (e.g. 'de', 'en')
      Bridge.prototype.Strings : [Key : String] -> {'Welcome': 'Willkommen'}
    */

    window.localizedString = function(string) {
      if (window.App === undefined || window.App.Bridge === undefined || window.App.Bridge.Strings === undefined) {
          return string;
      }
      var localizedString = window.App.Bridge.Strings[string];
      if (localizedString === undefined) {
          return string;
      }
      return localizedString;
    }

    /*
        Queries all DOM elements with attribute 'data-localizable-string' and replaces its text
        which its localized version if available.
    */
    window.localizeStrings = function() {
      var $localizableElements = $(LOCALIZABLE_QUERY_STRING);
      if ($localizableElements.length !== 0) {
          $localizableElements.each(function() {
              $(this).html(window.localizedString($(this).html()));
          });
      }
    }

    /*
        Queries all DOM img elements with attribute 'data-localizable-resource' and replaces its src, and srcset attributes
        which its localized version.
    */
    window.localizeResources = function() {
        $('img[data-localizable-resource]').each(function() {
            var $imgElement = $(this);
            var imageNameArray = $imgElement.attr('src').split('.');
            if (imageNameArray.size < 2) {
                  throw new Error('Cannot localizeResource: ' + $imgElement);
            }
            var localizedImageNames = window.localizedImageResource(imageNameArray[0], imageNameArray[1]);
            $imgElement.attr('src' ,localizedImageNames.img);
            $imgElement.attr('srcset' ,localizedImageNames.hdpiImage + ' 2x');
        });
    }

    /*
        Create localized name for supplied image name and extension.
        @return {Object} {image, hdpiImage}
    */
    window.localizedImageResource = function(name, extension) {
      if (window.App === undefined || window.App.Bridge === undefined) {
            return {
              image: name + '.' + extension,
              hdpiImage: name + '@2x.' + extension
            }
      }

      // var currentLocale = window.App.Bridge.currentLocale || 'en';
      // TODO: Currently we don't have localzied images available,
      // so we always use the non-localized english version.
      var currentLocale = 'en';
      var imageName = name + (currentLocale === 'en' ? '' : '_' + currentLocale);

      return {
        image:  imageName + '.' + extension,
        hdpiImage: imageName + '@2x.' + extension
      }
    }

})(window);
