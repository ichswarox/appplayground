(function(window) {
    'use strict';
    var $ = window.jQuery;
    var App = window.App || {};

    /*
        Attach media change listener detecting changes in the devices pixel ratio,
        forcing all img tags to reload img.
    */
    window.matchMedia('only screen and (-webkit-min-device-pixel-ratio: 2)').addListener(function(e) {
        $('img').each(function() {
            var image = this;
            image.src = image.src; // change src attribute forces reload
        });
    });

    App.Helper = {
        backingScale: function() {
            if (typeof window === 'object' && typeof window['devicePixelRatio'] === 'number') {
                return window.devicePixelRatio > 1 ? 2 : 1;
            }
            return 1;
        },
        Point: function(x, y) {
            this.left = x;
            this.top = y;
        }
    }

    window.App = App;

})(window);