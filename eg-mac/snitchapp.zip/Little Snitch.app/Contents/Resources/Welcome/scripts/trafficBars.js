(function(window) {
    'use strict';
    var $ = window.jQuery;
    var App = window.App || {};

    function TrafficBars($canvas) {
        if ($canvas === undefined) {
            throw new Error('TrafficBars: $canvas must be a vaild JQuery Object');
        }
        var can = $canvas[0];
        this.$canvas = $canvas;
        this.can = can;
        this.canHeight = can.height;
        this.canWidth = can.width;

        this.downTrafficBars = 0;
        this.uploadTrafficBars = 0;

        // performa initial drawing
        this.draw();
    }

    TrafficBars.prototype.setDownTraffic = function(traffic) {
        this.downTrafficBars = traffic;
        this.draw();
    }

    TrafficBars.prototype.setUploadTraffic = function(traffic) {
        this.uploadTrafficBars = traffic;
        this.draw();
    }

    TrafficBars.prototype.draw = function() {
        var can = this.can;
        var ctx = can.getContext('2d');
        if (ctx !== undefined) {
            var scaleFactor = window.App.Helper.backingScale();

            can.width = this.canWidth * scaleFactor;
            can.height = this.canHeight * scaleFactor;

            ctx = can.getContext('2d');

            ctx.clearRect(0, 0, can.width, can.heigth);

            var width = 6 * scaleFactor;
            var height = 2 * scaleFactor;
            var vSpacing = 1 * scaleFactor;
            var triangleHeight = 3 * scaleFactor;

            ctx.strokeStyle = "transparent";
            var onSelectedBackground = false; // this.$canvas.parents('[data-menuitem-state="selected"]').length > 0 ? true : false;
            var disabledBarColor = onSelectedBackground ? "rgba(255, 255, 255, 0.2)" : "rgba(0, 0, 0, 0.2)";

            _drawDownloadTrafficBar(ctx, 0, scaleFactor, width, height, vSpacing, triangleHeight, this.downTrafficBars, disabledBarColor);
            _drawUploadTrafficBar(ctx, width + 2 * scaleFactor, 0, scaleFactor, width, height, vSpacing, triangleHeight, this.uploadTrafficBars, disabledBarColor);
        }
    }

    function _drawDownloadTrafficBar(ctx, x, y, width, height, vSpacing, triangleHeight, activeBars, disabledBarColor) {
        var activeBarColor = "#88DA2F";
        ctx.fillStyle = activeBars > 0 ? activeBarColor : disabledBarColor;
        ctx.fillRect(x, y, width, height);
        ctx.fillStyle = activeBars > 1 ? activeBarColor : disabledBarColor;
        ctx.fillRect(x, y + height + vSpacing, width, height);
        ctx.fillStyle = activeBars > 2 ? activeBarColor : disabledBarColor;
        ctx.fillRect(x, y + (height + vSpacing) * 2, width, height);
        ctx.fillStyle = activeBars > 3 ? activeBarColor : disabledBarColor;
        ctx.fillRect(x, y + (height + vSpacing) * 3, width, height);
        ctx.fillStyle = activeBars > 4 ? activeBarColor : disabledBarColor;
        ctx.beginPath();
        ctx.moveTo(x, y + (height + vSpacing) * 4);
        ctx.lineTo(x + width, y + (height + vSpacing) * 4);
        ctx.lineTo(x + width / 2, y + (height + vSpacing) * 4 + triangleHeight);
        ctx.fill();
    }

    function _drawUploadTrafficBar(ctx, x, y, scaleFactor, width, height, vSpacing, triangleHeight, activeBars, disabledBarColor) {
        var activeBarColor = "#FF3C00";
        ctx.fillStyle = activeBars > 0 ? activeBarColor : disabledBarColor;
        ctx.fillRect(x, y + (height + vSpacing) * 4 + scaleFactor, width, height);
        ctx.fillStyle = activeBars > 1 ? activeBarColor : disabledBarColor;
        ctx.fillRect(x, y + (height + vSpacing) * 3 + scaleFactor, width, height);
        ctx.fillStyle = activeBars > 2 ? activeBarColor : disabledBarColor;
        ctx.fillRect(x, y + (height + vSpacing) * 2 + scaleFactor, width, height);
        ctx.fillStyle = activeBars > 3 ? activeBarColor : disabledBarColor;
        ctx.fillRect(x, y + (height + vSpacing) * 1 + scaleFactor, width, height);
        ctx.fillStyle = activeBars > 4 ? activeBarColor : disabledBarColor;
        ctx.beginPath();
        ctx.moveTo(x, y + triangleHeight);
        ctx.lineTo(x + width, y + triangleHeight);
        ctx.lineTo(x + width / 2, y);
        ctx.fill();
    }

    App.TrafficBars = TrafficBars;
    window.App = App;

})(window);