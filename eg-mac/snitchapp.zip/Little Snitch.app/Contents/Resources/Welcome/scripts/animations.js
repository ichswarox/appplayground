(function(window) {
    'use strict';

    var ANIMATION_DATA_ATTRIBUTE = 'data-animation';
    var START_ANIMATION_DATA_ATTRIBUTE = 'data-animation-start';

    /*
      usage examples:
      // animation_name, animation_delay
      <div data-animation="fade-in 0s"></div>
      -> fade-in div with delay of 0s and default animation duration

      // animation_name, animation_duration, animation_delay
      <div data-animation="fade-in 1s 500ms"></div>
      -> fade-in div with delay of 1s and duration of 500ms

      currently support animations:
      fade-in, shake, pulsate, translate, fade-out

      syntax:
      translate left top
      translate left top duration
      translate left top duration delay

      fade-in delay
      fade-in duration delay

      fade-out delay
      fade-out duration delay

      scale-in delay
      scale-in duration delay
    */

    var $ = window.jQuery;
    var App = window.App || {};

    /* #### HELPER ANIMATION */
    function _parseTime(value, defaultValue) {
        if (typeof value === 'string') {
            if (value.endsWith('ms')) {
                return parseInt(value);
            } else if (value.endsWith('s')) {
                return parseFloat(value) * 1000; // convert to ms
            }
        } else if (typeof value === 'number') {
            return value;
        }
        return defaultValue; // undefined
    }

    function _appendToAttribute($element, attributeName, textToAppend) {
        var currentValue = $element.attr(attributeName);
        if (currentValue === undefined) {
            currentValue = '';
        }
        $element.attr(attributeName, (currentValue + ' ' + textToAppend));
    }

    /* #### SHAKE ANIMATION */
    function _shake($element, args) {
        setTimeout(function() {
            $element.css({
                'transition-duration': (args[Animations.constants.args.duration] + 'ms'),
                'transition-delay': (args[Animations.constants.args.delay] + 'ms')
            });
            $element.addClass('animate-transition');
            setInterval(function() {
                var degree = $element.attr('data-rotate');
                degree = (degree === undefined) ? -5 + Math.random() * 10 : degree * -1;
                $element.css({
                    'transform': 'rotate(' + degree + 'deg)'
                });
                $element.attr('data-rotate', degree);
            }, args[Animations.constants.args.duration] + args[Animations.constants.args.delay]);
        }, 15);
    }

    /* #### PULSATE ANIMATION */
    function _pulsate($element, args) {
        setTimeout(function() {
            $element.css({
                'transition-duration': (args[Animations.constants.args.duration] + 'ms'),
                'transition-delay': (args[Animations.constants.args.delay] + 'ms')
            });
            $element.addClass('animate-transition');

            setTimeout(function() {
                var randomScale = (1 + Math.random() * 0.15);
                $element.css({
                    'transform': 'scale(' + randomScale + ')'
                });

                setInterval(function() {
                    var randomScale = (1 + Math.random() * 0.15);
                    $element.css({
                        'transform': 'scale(' + randomScale + ')'
                    });
                }, args[Animations.constants.args.duration] + args[Animations.constants.args.delay]);
            }, 15);
        }, 15);
    }

    /* #### FADEIN ANIMATION */
    function _fade(shouldFadeIn, $element, args, completionHandler) {
        $element.css({
            opacity: shouldFadeIn ? 0 : 1
        });

        args['css'] = {opacity: shouldFadeIn ? 1 : 0};
        _animateCSS($element, args, completionHandler);
    }

    function _fadeIn($element, args, completionHandler) {
        _fade(true, $element, args, completionHandler);
    }

    function _fadeOut($element, args, completionHandler) {
        _fade(false, $element, args, completionHandler);
    }

    function _animateCSS($element, args, completionHandler) {
        var animationDuration = Animations.constants.args.duration in args ? args[Animations.constants.args.duration] : Animations.animationDuration;
        var animationDelay = Animations.constants.args.delay in args ? args[Animations.constants.args.delay] : Animations.animationDelay;
        var timingFunction = Animations.constants.args.timing in args ? args[Animations.constants.args.timing] : 'linear';

        setTimeout(function() {
            setTimeout(function() {
                $element.css({
                    'transition-duration': '',
                });

                if (completionHandler !== undefined && typeof completionHandler == 'function') {
                    setTimeout(function() {
                        completionHandler();
                    }, 25);
                }
            }, animationDuration);
            $element.css({
                'transition-timing-function': timingFunction,
                'transition-duration': (animationDuration + 'ms')
            });
            $element.css(args.css);
        }, animationDelay);
    }

    /* #### SCALE-IN ANIMATION */
    function _scaleIn($element, args, completionHandler) {
        var updatesArgs = args;
        updatesArgs['css'] = { transform: 'scale(1.0)' };
        $element.css({ transform: 'scale(0.0)' });

        _animateCSS($element, updatesArgs, completionHandler);
    }

    function _move($element, args, completionHandler) {
        var position = $element.position();

        var updatedArgs = args;
        updatedArgs.css = {
            left: parseInt(args.left || position.left),
            top: parseInt(args.top || position.top)
        };

        _animateCSS($element, updatedArgs, completionHandler);
    }

    /* #### TRANSLATE ANIMATION */
    /*
      args -> Object
      {
        'duration' : [ms -> supplied as integer; ms, s if supplied as string]
        'delay' : [ms -> supplied as integer; ms, s if supplied as string],
        'left' : [in pixels]
        'top' : [in pixels]
      }
    */
    function _translate($element, args, completionHandler) {
        var position = $element.position();

        var updatedArgs = args;
        updatedArgs.css = {
            left: position.left + parseInt(args.left || 0),
            top: position.top + parseInt(args.top || 0)
        };

        _animateCSS($element, updatedArgs, completionHandler);
    }

    var Animations = {
        constants: {
            animations: {
                fadeIn: 'fade-in',
                fadeOut: 'fade-out',

                shake: 'shake',
                pulsate: 'pulsate',

                scaleIn: 'scale-in',

                move: 'move',
                translate: 'translate'
            },
            args: {
                animationName: 'animation',
                duration: 'duration',
                delay: 'delay',
                timing: 'timing'
            }
        },
        animateCSS: function($animatableObject, args, completionHandler) {
            _animateCSS($animatableObject, args, completionHandler);
        },

        animate: function($animatableObject, args, completionHandler) {
            if (typeof args === 'string') {
                args = _splitStringIntoARGS(args);
            }

            switch (args[this.constants.args.animationName]) {
                case this.constants.animations.shake:
                    _shake($animatableObject, args, completionHandler);
                    break;

                case this.constants.animations.fadeIn:
                    _fadeIn($animatableObject, args, completionHandler);
                    break;

                case this.constants.animations.fadeOut:
                    _fadeOut($animatableObject, args, completionHandler);
                    break;

                case this.constants.animations.scaleIn:
                    _scaleIn($animatableObject, args, completionHandler);
                    break;

                case this.constants.animations.pulsate:
                    _pulsate($animatableObject, args, completionHandler);
                    break;

                case this.constants.animations.move:
                    _move($animatableObject, args, completionHandler);
                    break;

                case this.constants.animations.translate:
                    _translate($animatableObject, args, completionHandler);
                    break;

                default:
                    var name = args[this.constants.args.animationName] || '[unspecified]';
                    throw new Error('Animation with name "' + name + '" not supported. Typo?');
            }
        }
    }

    Object.defineProperty(Animations, 'animationDuration', {
        value: 1250,
        writeable: true,
        configurable: false
    });

    Object.defineProperty(Animations, 'animationDelay', {
        value: 250,
        writeable: true,
        configurable: false
    });

    function _splitStringIntoARGS(input) {
        var args = [];

        var tokens = input.trim().split(' ');
        if (tokens.length < 1) {
            throw new Error('Animation: At least animation name needs to be provided');
        }
        var args = {};
        args[Animations.constants.args.animationName] = tokens[0];
        if (args[Animations.constants.args.animationName] === Animations.constants.animations.translate ||
            args[Animations.constants.args.animationName] === Animations.constants.animations.move) {
            args['left'] = tokens[1];
            args['top'] = tokens[2];

            if (tokens.length == 5) {
                args[Animations.constants.args.duration] = _parseTime(tokens[3], Animations.animationDuration);
            }
        } else {
            if (tokens.length == 3) {
                args[Animations.constants.args.duration] = _parseTime(tokens[1], Animations.animationDuration);
            }
        }

        args[Animations.constants.args.delay] = _parseTime(tokens[tokens.length - 1], Animations.animationDuration);

        return args;
    }

    // set up all Animations specified via HTML syntax
    function _initializeAnimationsProvidedViaHTMLAttributes() {
        var $animatableObjects = $('[' + ANIMATION_DATA_ATTRIBUTE + ']');
        $animatableObjects.each(function() {
            var $animatableObject = $(this);
            var animations = $animatableObject.attr(ANIMATION_DATA_ATTRIBUTE).split(';');
            animations.forEach(function(element) {
                Animations.animate($animatableObject, _splitStringIntoARGS(element), null);
            });
        });
    }

    App.Animations = Animations;
    window.App = App;

    _initializeAnimationsProvidedViaHTMLAttributes();

})(window);
